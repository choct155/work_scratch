#include "eigenbox.h"

int main(){
    apop_plot_lattice(query_data(), "out");
}
