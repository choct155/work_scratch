#include <apop.h>

void one_boot(gsl_vector *base_data, gsl_rng *r, gsl_vector* boot_sample);
